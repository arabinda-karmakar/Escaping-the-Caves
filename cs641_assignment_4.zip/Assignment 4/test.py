list=list("01101110010111100111101110000101100100110000001101010011")
list2 =[]
print(len(list))
for item in list:
    list2.append(int(item))
print(list2)

# %u%u1%u%u1%u%u%u10%u1%u10%u%u%u11%u%u11%u0%u0101100%u00110000%u01%u0101%u011